# God Bridge — Minecraft Forge 1.8.9

Minimal experimental mod source for Minecraft Java 1.8.9 / Forge 11.15.1.2318.

## Controls
- Press **B** to toggle the feature ON/OFF.
- Chat messages report `God Bridge: ON` and `God Bridge: OFF`.

## Build
Requires a compatible JDK 8 environment and internet access to resolve the legacy ForgeGradle 2.1 dependencies:

```bash
gradle build
```

The output JAR should appear in `build/libs/`.

## Install on PojavLauncher
Copy the built JAR into the `.minecraft/mods` folder for a Forge 1.8.9 installation.

## Important limitations
This is experimental source, not a verified release. It has **not** been compiled or tested in a live Minecraft/PojavLauncher session in this package-creation step. Automatic block placement depends on valid placement geometry, player position, available blocks, and Minecraft's normal interaction checks. Do not assume it will produce a perfect competitive God Bridge or work on multiplayer servers. Test in a creative/singleplayer world first.
