package com.godbridge.client;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(
    modid = GodBridgeClient.MODID,
    name = GodBridgeClient.NAME,
    version = GodBridgeClient.VERSION,
    clientSideOnly = true,
    acceptedMinecraftVersions = "[1.8.9]"
)
public class GodBridgeClient {
    public static final String MODID = "godbridge";
    public static final String NAME = "God Bridge";
    public static final String VERSION = "1.0.0";

    private final Minecraft mc = Minecraft.getMinecraft();
    private net.minecraft.client.settings.KeyBinding toggleKey;
    private boolean enabled = false;
    private long lastWarningTime = 0L;
    private long lastPlacementAttemptTick = 0L;

    @EventHandler
    public void init(FMLInitializationEvent event) {
        toggleKey = new net.minecraft.client.settings.KeyBinding(
            "key.godbridge.toggle", Keyboard.KEY_B, "God Bridge"
        );
        ClientRegistry.registerKeyBinding(toggleKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (toggleKey == null || !toggleKey.isPressed()) return;
        enabled = !enabled;
        if (mc.thePlayer != null) {
            mc.thePlayer.addChatMessage(new ChatComponentText(
                EnumChatFormatting.GOLD + "[God Bridge] " +
                (enabled
                    ? EnumChatFormatting.GREEN + "God Bridge: ON"
                    : EnumChatFormatting.RED + "God Bridge: OFF")
            ));
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !enabled) return;
        if (mc.thePlayer == null || mc.theWorld == null || mc.playerController == null) return;
        if (mc.currentScreen != null || mc.thePlayer.capabilities.isFlying) return;
        if (mc.thePlayer.isSpectator() || mc.thePlayer.isSneaking()) return;

        // Limit attempts to one per client tick and avoid repeated calls in the same tick.
        long tick = mc.theWorld.getTotalWorldTime();
        if (tick == lastPlacementAttemptTick) return;
        lastPlacementAttemptTick = tick;

        int blockSlot = getValidBlockSlot();
        if (blockSlot < 0) {
            warnNoBlocks();
            return;
        }

        // For a player standing on a block at Y, the next bridge block is normally at floor(posY)-1.
        int targetY = (int) Math.floor(mc.thePlayer.posY) - 1;
        BlockPos targetPos = getTargetPlacementPos(targetY);
        if (targetPos == null) return;

        PlacementTarget placement = findAnchor(targetPos);
        if (placement == null) return;

        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
        if (eyes.squareDistanceTo(placement.hitVec) > 18.0625D) return; // 4.25 blocks

        int oldSlot = mc.thePlayer.inventory.currentItem;
        if (oldSlot != blockSlot) mc.thePlayer.inventory.currentItem = blockSlot;
        ItemStack stack = mc.thePlayer.inventory.getCurrentItem();
        if (stack == null || !(stack.getItem() instanceof ItemBlock)) {
            mc.thePlayer.inventory.currentItem = oldSlot;
            return;
        }

        boolean placed = mc.playerController.onPlayerRightClick(
            mc.thePlayer, mc.theWorld, stack,
            placement.anchorPos, placement.facing, placement.hitVec
        );
        if (placed) mc.thePlayer.swingItem();
    }

    private BlockPos getTargetPlacementPos(int targetY) {
        BlockPos under = new BlockPos(mc.thePlayer.posX, targetY, mc.thePlayer.posZ);
        if (mc.theWorld.isAirBlock(under)) return under;

        // Predict a short distance in the direction of movement, only when moving.
        double px = mc.thePlayer.posX + mc.thePlayer.motionX * 1.25D;
        double pz = mc.thePlayer.posZ + mc.thePlayer.motionZ * 1.25D;
        if (Math.abs(mc.thePlayer.motionX) > 0.015D || Math.abs(mc.thePlayer.motionZ) > 0.015D) {
            BlockPos predicted = new BlockPos(px, targetY, pz);
            if (mc.theWorld.isAirBlock(predicted)) return predicted;
        }
        return null;
    }

    private PlacementTarget findAnchor(BlockPos target) {
        EnumFacing[] directions = new EnumFacing[] {
            EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.WEST,
            EnumFacing.EAST, EnumFacing.DOWN, EnumFacing.UP
        };
        for (EnumFacing dir : directions) {
            BlockPos anchor = target.offset(dir);
            IBlockState state = mc.theWorld.getBlockState(anchor);
            Block block = state.getBlock();
            if (mc.theWorld.isAirBlock(anchor) || block.isReplaceable(mc.theWorld, anchor)) continue;
            if (!block.getMaterial().isSolid()) continue;

            EnumFacing face = dir.getOpposite();
            Vec3 hit = new Vec3(
                anchor.getX() + 0.5D + face.getFrontOffsetX() * 0.5D,
                anchor.getY() + 0.5D + face.getFrontOffsetY() * 0.5D,
                anchor.getZ() + 0.5D + face.getFrontOffsetZ() * 0.5D
            );
            return new PlacementTarget(anchor, face, hit);
        }
        return null;
    }

    private int getValidBlockSlot() {
        int selected = mc.thePlayer.inventory.currentItem;
        if (isPlaceableBlock(mc.thePlayer.inventory.getStackInSlot(selected))) return selected;
        for (int i = 0; i < 9; i++) {
            if (isPlaceableBlock(mc.thePlayer.inventory.getStackInSlot(i))) return i;
        }
        return -1;
    }

    private boolean isPlaceableBlock(ItemStack stack) {
        if (stack == null || stack.stackSize <= 0 || !(stack.getItem() instanceof ItemBlock)) return false;
        Block block = ((ItemBlock) stack.getItem()).getBlock();
        return block.isFullCube() || block.isNormalCube();
    }

    private void warnNoBlocks() {
        long now = System.currentTimeMillis();
        if (now - lastWarningTime < 3000L) return;
        mc.thePlayer.addChatMessage(new ChatComponentText(
            EnumChatFormatting.RED + "[God Bridge] No suitable blocks in hotbar."
        ));
        lastWarningTime = now;
    }

    private static class PlacementTarget {
        final BlockPos anchorPos;
        final EnumFacing facing;
        final Vec3 hitVec;
        PlacementTarget(BlockPos anchorPos, EnumFacing facing, Vec3 hitVec) {
            this.anchorPos = anchorPos;
            this.facing = facing;
            this.hitVec = hitVec;
        }
    }
}
